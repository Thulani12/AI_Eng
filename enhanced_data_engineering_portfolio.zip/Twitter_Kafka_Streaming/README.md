# Twitter Kafka Streaming

This project streams tweets using Twitter API and pushes them to Kafka.