# Airflow Daily ETL

This Airflow DAG runs a daily ETL job with task retries and backfill.