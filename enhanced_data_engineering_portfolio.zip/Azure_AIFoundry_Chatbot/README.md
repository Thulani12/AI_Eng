# Azure AI Foundry Chatbot

This chatbot uses Azure AI Foundry to interact with GPT-4.