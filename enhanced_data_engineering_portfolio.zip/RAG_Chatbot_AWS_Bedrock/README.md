# RAG Chatbot with AWS Bedrock

This Python script integrates LangChain with AWS Bedrock for a Retrieval-Augmented Generation chatbot.