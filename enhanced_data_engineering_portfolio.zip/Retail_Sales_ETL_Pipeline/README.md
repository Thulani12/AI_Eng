# Retail Sales ETL Pipeline

This Python script ingests retail sales data, cleans it, aggregates totals, and loads it into AWS S3.