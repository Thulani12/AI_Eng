# Web Log Analysis

This PySpark script parses Apache logs and summarizes key metrics.